---
obsidianUIMode: preview
---

The following list contains connections between locations in a large underground realm. Roll once or twice to build connections between locations in the underworld.

`dice: [[31 - Random Connectors#^random-connectors]]`

1. Long-abandoned sewers
2. Ancient burial chambers
3. Underground river
4. Tunnels carved by ancient laborers
5. Massive worm-carved passageways
6. Narrow pathway alongside a deep fissure
7. Tunnels illuminated with phosphorescent fungi
8. Spiraling shaft
9. Abandoned mine tunnels
10. Primeval tunnels adorned with thousands of handprints
11. Smooth tunnels bored out with magic
12. Natural tunnel strewn with webs
13. Underwater passage
14. Moss-covered natural tunnel
15. Collapsing sinkhole leading to tunnel network
16. Ice tunnel
17. Cooled lava flow
18. Huge bridge over a deep chasm
19. Otherworldly passage
20. Massive platforms crossing a bottomless pit

^random-connectors
